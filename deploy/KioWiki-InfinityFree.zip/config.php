<?php
return ['setup_on_home' => true];
